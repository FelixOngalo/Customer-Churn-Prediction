# Predicting customer churn with tidymodels.
#
# The goal here is an INTERPRETABLE model, not a maximally complex one.
# A logistic regression, compared against a simple baseline, communicates
# well to a non-technical audience -- which matters as much as accuracy
# in an analyst role.

library(tidymodels)
library(dplyr)

df <- readRDS("data/clean/churn_clean.rds")

# 1. Split: hold out 20% of customers, never touched until final evaluation.
#    strata = churn keeps the churn rate similar in both sets.
set.seed(123)
split <- initial_split(df, prop = 0.8, strata = churn)
train <- training(split)
test  <- testing(split)

# 2. Cross-validation folds on the TRAINING set only, for tuning/comparison.
folds <- vfold_cv(train, v = 5, strata = churn)

# 3. Preprocessing recipe: every transformation is learned from train only,
#    then applied identically to test -- this prevents data leakage.
rec <- recipe(churn ~ ., data = train) |>
  step_novel(all_nominal_predictors()) |>
  step_dummy(all_nominal_predictors()) |>
  step_zv(all_predictors()) |>
  step_normalize(all_numeric_predictors())

# 4. Two model specs to compare: a simple baseline and logistic regression.
null_spec <- null_model() |> set_engine("parsnip") |> set_mode("classification")
log_spec  <- logistic_reg() |> set_engine("glm") |> set_mode("classification")

null_wf <- workflow() |> add_recipe(rec) |> add_model(null_spec)
log_wf  <- workflow() |> add_recipe(rec) |> add_model(log_spec)

metrics <- metric_set(roc_auc, accuracy, sens, spec)

# 5. Cross-validate both, so the comparison isn't due to one lucky split.
null_res <- fit_resamples(null_wf, folds, metrics = metrics)
log_res  <- fit_resamples(log_wf,  folds, metrics = metrics,
                          control = control_resamples(save_pred = TRUE))

cat("== Baseline (predicts the majority class every time) ==\n")
print(collect_metrics(null_res))
cat("\n== Logistic regression (cross-validated) ==\n")
print(collect_metrics(log_res))

# 6. Fit the chosen model on the FULL training set, evaluate ONCE on test.
final_fit <- log_wf |> fit(train)

test_results <- test |>
  bind_cols(predict(final_fit, test, type = "prob")) |>
  bind_cols(predict(final_fit, test)) |>
  rename(pred_class = .pred_class)

cat("\n== Held-out test set performance ==\n")
print(metrics(test_results, truth = churn, estimate = pred_class,
              .pred_Yes, event_level = "second"))

conf_mat <- conf_mat(test_results, truth = churn, estimate = pred_class)
print(conf_mat)

saveRDS(final_fit, "models/logistic_churn_model.rds")
saveRDS(test_results, "data/clean/test_results.rds")
saveRDS(log_res, "data/clean/cv_predictions.rds")
