# Data: "Telco Customer Churn" (IBM sample dataset, widely used for churn practice).
#   Kaggle: search "Telco Customer Churn" (blastchar/telco-customer-churn)
# Download the CSV and save it as data/raw/telco_churn.csv
#
# Columns include customer demographics, account info (tenure, contract type,
# payment method), the services they subscribe to, monthly/total charges,
# and Churn (Yes/No) -- the outcome we're predicting.

message("Download the Telco Customer Churn CSV and save it as data/raw/telco_churn.csv")
