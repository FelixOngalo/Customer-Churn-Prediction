library(readr)
source("R/cleaning.R")

raw   <- read_csv("data/raw/telco_churn.csv", show_col_types = FALSE)
clean <- clean_churn(raw)

cat("Rows before:", nrow(raw), "\n")
cat("Rows after: ", nrow(clean), "\n")
cat("Churn rate: ", scales::percent(mean(clean$churn == "Yes")), "\n")

saveRDS(clean, "data/clean/churn_clean.rds")
