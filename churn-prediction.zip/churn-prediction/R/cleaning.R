library(dplyr)
library(janitor)
library(stringr)

clean_churn <- function(raw) {
  raw |>
    clean_names() |>
    filter(!is.na(total_charges), total_charges != "") |>   # a handful of blank rows in the source file
    mutate(
      total_charges = as.numeric(total_charges),
      churn         = factor(churn, levels = c("No", "Yes")),  # "Yes" = the event we're predicting
      senior_citizen = factor(senior_citizen, labels = c("No", "Yes"))
    ) |>
    select(-customer_id)
}
