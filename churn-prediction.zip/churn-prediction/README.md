# Customer Churn Prediction

**Question:** *(fill in)* Which customers are likely to churn, and what factors drive that risk?

**Key findings:** *(fill in after running; AUC vs baseline, top 2-3 drivers)*

**Tools:** R, tidymodels, logistic regression, Quarto

## Why this project

Shows the full modeling workflow end to end: a proper train/test split, cross-validation, a documented preprocessing recipe, a baseline for comparison, and a model chosen for interpretability over raw complexity — the kind of workflow an analyst role expects, not just "fit a model and report accuracy."

## Reproduce

1. Download the Telco Customer Churn dataset (see `R/00_get_data.R`) and save it as `data/raw/telco_churn.csv`
2. `install.packages(c("tidymodels", "tidyverse", "janitor", "scales", "quarto"))`
3. Run in order:
   - `R/01_clean.R`
   - `R/02_train_model.R`
   - Render `reports/report.qmd`

## Modeling workflow

1. **Split** the data before touching anything else (80/20, stratified).
2. **Cross-validate** on the training set to compare models without ever peeking at test data.
3. **Preprocess** with a `recipe()` — every step is learned from training data only, then applied identically to new data, which prevents leakage.
4. **Compare** a null baseline against logistic regression.
5. **Evaluate once** on the untouched test set.
6. **Interpret** coefficients as odds ratios: what actually predicts churn, in plain English.

## Key concepts

| Concept | Plain-English meaning |
|---|---|
| Train/test split | Fit the model on one part, judge it on data it never saw |
| Stratified split | Keep the churn rate similar in both parts |
| Cross-validation | Compare models several times on different slices before final testing |
| Data leakage | Accidentally letting test information influence training |
| Baseline model | The simplest possible prediction, to prove the real model adds value |
| AUC | How well the model ranks churners above non-churners, across all thresholds |
| Sensitivity / specificity | Catching actual churners vs not over-flagging loyal customers |
| Odds ratio | How much a factor multiplies the odds of churning |

## Structure

```
R/00_get_data.R        where to get the data
R/cleaning.R            cleaning function
R/01_clean.R            run cleaning
R/02_train_model.R      split, cross-validate, fit, evaluate
reports/report.qmd      write-up: performance, drivers, recommendation
models/                 saved fitted model
```

## Limitations

*(fill in)*
